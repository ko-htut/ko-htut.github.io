(function($){
	$(document).ready(function(){
		//Empty space. Fill this with your site specific JS code
	});
})(jQuery);